import React, { useState } from "react";

function BookingForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    date: "",
    time: "",
    guests: "",
  });
  const [errors, setErrors] = useState({});

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name) newErrors.name = "Name is required.";
    if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email))
      newErrors.email = "Valid email is required.";
    if (!formData.date) newErrors.date = "Date is required.";
    if (!formData.time) newErrors.time = "Time is required.";
    if (!formData.guests || isNaN(formData.guests) || formData.guests < 1)
      newErrors.guests = "Number of guests must be at least 1.";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      alert("Booking successfully submitted!");
      setFormData({
        name: "",
        email: "",
        date: "",
        time: "",
        guests: "",
      });
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="booking-form"
      aria-label="Booking Form"
    >
      <h2>Book a Table</h2>

      <div>
        <label htmlFor="name">Name:</label>
        <input
          type="text"
          id="name"
          name="name"
          value={formData.name}
          onChange={handleInputChange}
          aria-required="true"
          aria-invalid={errors.name ? "true" : "false"}
        />
        {errors.name && <span className="error">{errors.name}</span>}
      </div>

      <div>
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          id="email"
          name="email"
          value={formData.email}
          onChange={handleInputChange}
          aria-required="true"
          aria-invalid={errors.email ? "true" : "false"}
        />
        {errors.email && <span className="error">{errors.email}</span>}
      </div>

      <div>
        <label htmlFor="date">Date:</label>
        <input
          type="date"
          id="date"
          name="date"
          value={formData.date}
          onChange={handleInputChange}
          aria-required="true"
          aria-invalid={errors.date ? "true" : "false"}
        />
        {errors.date && <span className="error">{errors.date}</span>}
      </div>

      <div>
        <label htmlFor="time">Time:</label>
        <input
          type="time"
          id="time"
          name="time"
          value={formData.time}
          onChange={handleInputChange}
          aria-required="true"
          aria-invalid={errors.time ? "true" : "false"}
        />
        {errors.time && <span className="error">{errors.time}</span>}
      </div>

      <div>
        <label htmlFor="guests">Number of Guests:</label>
        <input
          type="number"
          id="guests"
          name="guests"
          value={formData.guests}
          onChange={handleInputChange}
          aria-required="true"
          aria-invalid={errors.guests ? "true" : "false"}
        />
        {errors.guests && <span className="error">{errors.guests}</span>}
      </div>

      <button type="submit">Submit</button>
    </form>
  );
}

export default BookingForm;
